// import React, { useState, useEffect } from "react";
// import ChatHeader from "./ChatHeader";
// import MessageList from "./MessageList";
// import MessageInput from "./MessageInput";
// import { findConversation } from "../../API/ChatList"; // Импортируем функцию из API

// interface IUser {
//   id: string;
//   name: string;
//   avatarUrl?: string;
// }

// interface IMessage {
//   id: string;
//   text: string;
//   timestamp: string;
//   senderId: string;
//   isOwn: boolean;
//   attachments: string[];
// }

// interface ChatWindowProps {
//   user: IUser; // Пользователь, от имени которого идет переписка
//   receiverId: string; // ID получателя, с которым ведется переписка
//   receiveName: string;
// }

// const ChatWindow: React.FC<ChatWindowProps> = ({ user, receiverId, receiveName }) => {
//   const [messages, setMessages] = useState<IMessage[]>([]); // Сообщения чата
//   const [loading, setLoading] = useState<boolean>(true); // Индикатор загрузки
//   const [error, setError] = useState<string | null>(null); // Ошибка при загрузке

//   // Загрузка сообщений при первом рендере или смене получателя
//   useEffect(() => {
//     const loadMessages = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         // Вызываем функцию для получения сообщений
//         const data = await findConversation(user.id, receiverId);

//         // Преобразуем данные с сервера в формат компонента
//         const formattedMessages = data.map((msg: any) => ({
//           id: msg.id,
//           text: msg.content,
//           timestamp: new Date(msg.created_at).toLocaleTimeString(),
//           senderId: msg.sender_id,
//           isOwn: msg.sender_id === user.id,
//           attachments: [], // Если есть вложения, их нужно обработать
//         }));

//         setMessages(formattedMessages);
//       } catch (err) {
//         setError("Не удалось загрузить сообщения.");
//         console.error(err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     loadMessages();
//   }, [user.id, receiverId]);

//   // Отправка сообщения на сервер
//   const sendMessageToServer = async (message: IMessage) => {
//     try {
//       // Здесь можно реализовать отправку сообщения на сервер через API
//       // Например:
//       // await sendMessageAPI(message);
//       console.log("Отправка сообщения на сервер:", message);
//     } catch (err) {
//       console.error("Ошибка при отправке сообщения:", err);
//     }
//   };

//   // Функция отправки нового сообщения
//   const handleSendMessage = async (text: string, attachmentFiles: File[]) => {
//     if (!text && attachmentFiles.length === 0) return;

//     const newMessage: IMessage = {
//       id: Date.now().toString(), // Уникальный ID сообщения
//       text,
//       timestamp: new Date().toLocaleTimeString(),
//       senderId: user.id, // Отправитель — текущий пользователь
//       isOwn: true, // Устанавливаем isOwn на основе текущего пользователя
//       attachments: attachmentFiles.map((file) => URL.createObjectURL(file)), // Пример использования URL
//     };

//     // Добавляем сообщение локально
//     setMessages((prev) => [...prev, newMessage]);

//     // Отправляем сообщение на сервер
//     await sendMessageToServer(newMessage);
//   };

//   return (
//     <div className="flex flex-col flex-grow bg-white h-screen">
//       <ChatHeader receiveName={receiveName} />

//       {/* Загрузка или отображение ошибок */}
//       {loading && <p className="p-4 text-gray-500">Загрузка сообщений...</p>}
//       {error && <p className="p-4 text-red-500">{error}</p>}

//       {/* Список сообщений */}
//       {!loading && !error && <MessageList messages={messages} />}

//       {/* Поле ввода и прикрепления файлов */}
//       <MessageInput onSend={handleSendMessage} userId={user.id} receiverId={receiverId} />
//     </div>
//   );
// };

// export default ChatWindow;

// // import React, { useState, useEffect } from "react";
// // import ChatHeader from "./ChatHeader";
// // import MessageList from "./MessageList";
// // import MessageInput from "./MessageInput";
// // import { findConversation } from "../../API/ChatList"; // Импортируем функцию из API


// // interface IUser {
// //   id: string;
// //   name: string;
// //   avatarUrl?: string;
// // }

// // interface IMessage {
// //   id: string;
// //   text: string;
// //   timestamp: string;
// //   senderId: string;
// //   isOwn: boolean;
// //   attachments: string[];
// // }

// // interface ChatWindowProps {
// //   user: IUser; // Пользователь, от имени которого идет переписка
// //   receiverId: string; // ID получателя, с которым ведется переписка
// //   receiveName:string;
// // }

// // const ChatWindow: React.FC<ChatWindowProps> = ({ user, receiverId ,receiveName}) => {
// //   const [messages, setMessages] = useState<IMessage[]>([]); // Сообщения чата
// //   const [loading, setLoading] = useState<boolean>(true); // Индикатор загрузки
// //   const [error, setError] = useState<string | null>(null); // Ошибка при загрузке

// //   // Загрузка сообщений при первом рендере или смене получателя
// //   useEffect(() => {
// //     const loadMessages = async () => {
// //       try {
// //         setLoading(true);
// //         setError(null);

// //         // Вызываем функцию для получения сообщений
// //         const data = await findConversation(user.id, receiverId);

// //         // Преобразуем данные с сервера в формат компонента
// //         const formattedMessages = data.map((msg: any) => ({
// //           id: msg.id,
// //           text: msg.content,
// //           timestamp: new Date(msg.created_at).toLocaleTimeString(),
// //           senderId: msg.sender_id,
// //           isOwn: msg.sender_id === user.id,
// //           attachments: [], // Если есть вложения, их нужно обработать
// //         }));

// //         setMessages(formattedMessages);
// //       } catch (err) {
// //         setError("Не удалось загрузить сообщения.");
// //         console.error(err);
// //       } finally {
// //         setLoading(false);
// //       }
// //     };

// //     loadMessages();
// //   }, [user.id, receiverId]);

// //   // Отправка сообщения на сервер (пример заглушки)
// //   const sendMessageToServer = async (message: IMessage) => {
// //     try {
// //       console.log("Отправка сообщения на сервер:", message);
// //       // Здесь можно отправить данные на сервер через API
// //     } catch (err) {
// //       console.error("Ошибка при отправке сообщения:", err);
// //     }
// //   };

// //   // Функция отправки нового сообщения
// //   const handleSendMessage = async (text: string, attachmentFiles: File[]) => {
// //     if (!text && attachmentFiles.length === 0) return;

// //     const newMessage: IMessage = {
// //       id: Date.now().toString(), // Уникальный ID сообщения
// //       text,
// //       timestamp: new Date().toLocaleTimeString(),
// //       senderId: user.id, // Отправитель — текущий пользователь
// //       isOwn: true, // Устанавливаем isOwn на основе текущего пользователя
// //       attachments: attachmentFiles.map((file) => URL.createObjectURL(file)), // Пример использования URL
// //     };

// //     // Добавляем сообщение локально
// //     setMessages((prev) => [...prev, newMessage]);

// //     // Отправляем сообщение на сервер
// //     await sendMessageToServer(newMessage);
// //   };

// //   return (
// //     <div className="flex flex-col flex-grow bg-white h-screen">
// //       <ChatHeader receiveName={receiveName} />

// //       {/* Загрузка или отображение ошибок */}
// //       {loading && <p className="p-4 text-gray-500">Загрузка сообщений...</p>}
// //       {error && <p className="p-4 text-red-500">{error}</p>}

// //       {/* Список сообщений */}
// //       {!loading && !error && <MessageList messages={messages} />}

// //       {/* Поле ввода и прикрепления файлов */}
// //       <MessageInput onSend={handleSendMessage} userId={user.id}  receiverId={receiverId} />
// //     </div>
// //   );
// // };

// // export default ChatWindow;
import React, { useState, useEffect } from "react";
import ChatHeader from "./ChatHeader";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import { findConversation } from "../../API/ChatList"; // Импортируем функцию из API

interface IUser {
  id: string;
  name: string;
  avatarUrl?: string;
}

interface IMessage {
  id: string;
  text: string;
  timestamp: string;
  senderId: string;
  isOwn: boolean;
  attachments: string[];
}

interface ChatWindowProps {
  user: IUser; // Пользователь, от имени которого идет переписка
  receiverId: string; // ID получателя, с которым ведется переписка
  receiveName: string;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ user, receiverId, receiveName }) => {
  const [messages, setMessages] = useState<IMessage[]>([]); // Сообщения чата
  const [loading, setLoading] = useState<boolean>(true); // Индикатор загрузки
  const [error, setError] = useState<string | null>(null); // Ошибка при загрузке

  // Загрузка сообщений при первом рендере или смене получателя
  useEffect(() => {
    const loadMessages = async () => {
      try {
        setLoading(true);
        setError(null);

        // Вызываем функцию для получения сообщений
        const data = await findConversation(user.id, receiverId);

        // Преобразуем данные с сервера в формат компонента
        const formattedMessages = data.map((msg: any) => ({
          id: msg.id,
          text: msg.content,
          timestamp: new Date(msg.created_at).toLocaleTimeString(),
          senderId: msg.sender_id,
          isOwn: msg.sender_id === user.id,
          attachments: msg.attachments || [], // Обработка вложений, если они есть
        }));

        setMessages(formattedMessages);
      } catch (err) {
        setError("Не удалось загрузить сообщения.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadMessages();
  }, [user.id, receiverId]);

  // Отправка сообщения на сервер
  const sendMessageToServer = async (message: IMessage) => {
    try {
      // Здесь можно реализовать отправку сообщения на сервер через API
      // Например:
      // await sendMessageAPI(message);
      console.log("Отправка сообщения на сервер:", message);
    } catch (err) {
      console.error("Ошибка при отправке сообщения:", err);
    }
  };

  // Функция отправки нового сообщения
  const handleSendMessage = async (messageId: string, text: string, attachmentFiles: File[]) => {
    if (!text && attachmentFiles.length === 0) return;

    const newMessage: IMessage = {
      id: messageId, // Используем предоставленный ID
      text,
      timestamp: new Date().toLocaleTimeString(),
      senderId: user.id, // Отправитель — текущий пользователь
      isOwn: true, // Устанавливаем isOwn на основе текущего пользователя
      attachments: attachmentFiles.map((file) => URL.createObjectURL(file)), // Пример использования URL
    };

    // Добавляем сообщение локально
    setMessages((prev) => [...prev, newMessage]);

    // Отправляем сообщение на сервер
    await sendMessageToServer(newMessage);
  };

  return (
    <div className="flex flex-col flex-grow bg-white h-screen">
      <ChatHeader receiveName={receiveName} />

      {/* Загрузка или отображение ошибок */}
      {loading && <p className="p-4 text-gray-500">Загрузка сообщений...</p>}
      {error && <p className="p-4 text-red-500">{error}</p>}

      {/* Список сообщений */}
      {!loading && !error && <MessageList messages={messages} />}

      {/* Поле ввода и прикрепления файлов */}
      <MessageInput onSend={handleSendMessage} userId={user.id} receiverId={receiverId} />
    </div>
  );
};

export default ChatWindow;
