export interface LoginDTO {
    identifier: string; // Email or Phone 
    password: string;
  }
  