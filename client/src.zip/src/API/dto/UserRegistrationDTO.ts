export interface UserRegistrationDTO {
    name: string;
    nickname: string;
    email: string;
    phone_number: string;
    password: string;
  }
  
//   {
//     "email": "jansmith@example.com",
//     "password": "hashedpassword456",
//     "nickname": "janey9",
//     "phone_number": "+09870654321"
//   }